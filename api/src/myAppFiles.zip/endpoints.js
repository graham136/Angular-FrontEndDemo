/** 
 * Configure your endpoints
*/
module.exports = function () {
	return {
		accounts: require('./controllers/accounts.json')		
	}
};